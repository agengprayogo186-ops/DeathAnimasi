package id.zentra.deathdimension;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Adegan di realm: badan pemain tergeletak (dibangun dari display entity, kepala = skin pemain)
 * dan kamera (display entity tak terlihat) yang menjauh lalu berputar pelan. Pemain mode spectator
 * yang "menonton" kamera itu, jadi tampilannya seperti third-person otomatis.
 */
final class Cinematic {

    private final DeathDimension plugin;
    private final NamespacedKey tagKey;
    private final Location origin;
    private final float bodyAngle;
    private final float headScale;
    private final ItemStack headItem;
    private final List<Entity> parts = new ArrayList<>();
    private ItemDisplay camera;
    private int lastCheck;

    Cinematic(DeathDimension plugin, Player p, Location floor, float yawDeg, float headScale) {
        this.plugin = plugin;
        this.tagKey = new NamespacedKey(plugin, "cine");
        this.origin = floor.clone();
        this.origin.setYaw(0f);
        this.origin.setPitch(0f);
        this.bodyAngle = (float) -Math.toRadians(yawDeg);
        this.headScale = headScale;
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (head.getItemMeta() instanceof SkullMeta m) {
            m.setOwningPlayer(p);
            head.setItemMeta(m);
        }
        this.headItem = head;
        buildCorpse();
        spawnCamera();
    }

    ItemDisplay camera() { return camera; }

    // ------------------------------------------------------------ build

    private void tag(Entity e) {
        e.getPersistentDataContainer().set(tagKey, PersistentDataType.BYTE, (byte) 1);
        e.setPersistent(false);
    }

    private Vector3f rot(Vector3f v) {
        return new Quaternionf().rotateY(bodyAngle).transform(v);
    }

    private void box(float x, float y, float z, float sx, float sy, float sz, Material m) {
        final Vector3f t = rot(new Vector3f(x, y, z));
        BlockDisplay d = origin.getWorld().spawn(origin, BlockDisplay.class, e -> {
            tag(e);
            e.setBlock(m.createBlockData());
            e.setBrightness(new Display.Brightness(13, 13));
            e.setTransformation(new Transformation(t, new AxisAngle4f(bodyAngle, 0f, 1f, 0f),
                    new Vector3f(sx, sy, sz), new AxisAngle4f()));
        });
        parts.add(d);
    }

    private void buildCorpse() {
        // lokal: x = lebar, y = atas, z = panjang badan (kepala di -z, kaki di +z). Berbaring telentang.
        box(-0.25f, 0f, -0.5f, 0.5f, 0.25f, 0.75f, Material.CYAN_CONCRETE);          // badan
        box(-0.25f, 0f, 0.25f, 0.25f, 0.25f, 0.75f, Material.BLUE_CONCRETE);         // kaki
        box(0f, 0f, 0.25f, 0.25f, 0.25f, 0.75f, Material.BLUE_CONCRETE);
        box(-0.25f, 0.25f, -0.45f, 0.5f, 0.2f, 0.25f, Material.ORANGE_TERRACOTTA);   // tangan menyilang di dada
        box(-0.25f, 0.25f, -0.2f, 0.5f, 0.2f, 0.25f, Material.ORANGE_TERRACOTTA);
        final Vector3f ht = rot(new Vector3f(0f, 0.25f, -0.75f));
        ItemDisplay head = origin.getWorld().spawn(origin, ItemDisplay.class, e -> {
            tag(e);
            e.setItemStack(headItem);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
            e.setBrightness(new Display.Brightness(13, 13));
            e.setTransformation(new Transformation(ht, new AxisAngle4f(bodyAngle, 0f, 1f, 0f),
                    new Vector3f(headScale, headScale, headScale), new AxisAngle4f()));
        });
        parts.add(head);
    }

    private void spawnCamera() {
        Location l = origin.clone().add(0, 1, 0);
        camera = origin.getWorld().spawn(l, ItemDisplay.class, e -> {
            tag(e);
            e.setTeleportDuration(2);
        });
    }

    // ------------------------------------------------------------ per tick

    private static double ease(double x) { return 1 - Math.pow(1 - x, 3); }

    void tick(Player p, int age) {
        if (age - lastCheck >= 20) {
            lastCheck = age;
            ensure();
        }
        double t = age / 20.0;
        double pull = ease(Math.min(1.0, t / 6.0));
        double dist = 0.8 + pull * 6.2;
        double height = 0.7 + pull * 3.3 + Math.sin(t * 0.7) * 0.2 * pull;
        double psi = t * 0.22;

        Vector3f off = new Quaternionf().rotateY((float) (bodyAngle + psi))
                .transform(new Vector3f(0f, (float) height, (float) -dist));
        Location cl = origin.clone().add(off.x, off.y, off.z);
        Vector3f aim = rot(new Vector3f(0f, 0.25f, (float) (-0.75 + 0.75 * pull)));
        cl.setDirection(new Vector(origin.getX() + aim.x - cl.getX(),
                origin.getY() + aim.y - cl.getY(),
                origin.getZ() + aim.z - cl.getZ()));
        camera.teleport(cl);

        if (p.getGameMode() == GameMode.SPECTATOR && !camera.equals(p.getSpectatorTarget()))
            p.setSpectatorTarget(camera);

        particles(age, t);
    }

    private void particles(int age, double t) {
        World w = origin.getWorld();
        double a = t * 2.2;
        double h = (age % 60) / 60.0 * 5.0;
        for (int k = 0; k < 2; k++) {
            double aa = a + k * Math.PI;
            Location sp = origin.clone().add(Math.cos(aa) * 0.6, 0.4 + h, Math.sin(aa) * 0.6);
            w.spawnParticle(Particle.SOUL_FIRE_FLAME, sp, 1, 0, 0, 0, 0);
        }
        w.spawnParticle(Particle.END_ROD, origin.clone().add(0, 2.5, 0), 2, 0.05, 2.5, 0.05, 0.0);
        if (age % 3 == 0)
            w.spawnParticle(Particle.CHERRY_LEAVES, origin.clone().add(0, 4.5, 0), 3, 3.0, 0.5, 3.0, 0.0);
        if (age % 10 == 0)
            w.spawnParticle(Particle.SOUL, origin.clone().add(0, 0.4, 0), 4, 1.2, 0.2, 1.2, 0.02);
    }

    /** Kalau entity ikut terhapus (clearlag, dll) -> buat ulang. */
    private void ensure() {
        if (camera == null || !camera.isValid()) spawnCamera();
        if (!parts.isEmpty() && !parts.get(0).isValid()) {
            for (Entity e : parts) e.remove();
            parts.clear();
            buildCorpse();
        }
    }

    void remove() {
        if (camera != null) camera.remove();
        for (Entity e : parts) e.remove();
        parts.clear();
    }
}
