package id.zentra.deathdimension;

import com.destroystokyo.paper.event.player.PlayerStopSpectatingEntityEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public final class RealmListener implements Listener {

    private final DeathDimension plugin;
    private final RealmManager realm;

    public RealmListener(DeathDimension plugin, RealmManager realm) {
        this.plugin = plugin;
        this.realm = realm;
    }

    /** Jalur utama: batalkan kematian, mainkan animasi. Tidak ada respawn sama sekali. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (realm.isBusy(p) || realm.isProtected(p)) {
            e.setCancelled(true);
            return;
        }
        if (!realm.shouldHandle(p)) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        if (hasTotem(p)) return;
        e.setCancelled(true);
        realm.startPull(p);
    }

    private boolean hasTotem(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    /** Jalur cadangan: mati lewat /kill, setHealth(0), dsb. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!realm.isBusy(p) && !realm.shouldHandle(p)) return;
        if (plugin.getConfig().getBoolean("keep-inventory", true)) {
            e.setKeepInventory(true);
            e.setKeepLevel(true);
            e.getDrops().clear();
            e.setDroppedExp(0);
        }
        realm.markPending(p);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && p.isDead()) p.spigot().respawn();
        });
    }

    /** HIGHEST + verifikasi ulang di RealmManager.forceTo = tidak bisa ditimpa plugin respawn/RTP. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (!realm.consumePending(p)) return;
        Location dest = realm.realmLocation();
        if (dest == null) return;
        e.setRespawnLocation(dest);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) realm.enterNow(p);
        });
    }

    /** Selama di realm, tidak ada plugin lain yang boleh memindahkan pemain keluar. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        if (!realm.isInRealm(p) || realm.isInternalTeleport(p)) return;
        Location dest = realm.realmLocation();
        if (dest == null || e.getTo() == null) return;
        if (!dest.getWorld().equals(e.getTo().getWorld())
                || e.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE) e.setCancelled(true);
    }

    /** Pemain tidak boleh keluar dari kamera (shift) atau ganti gamemode lewat plugin/skript lain. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onStopSpectating(PlayerStopSpectatingEntityEvent e) {
        if (realm.isInRealm(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGameMode(PlayerGameModeChangeEvent e) {
        Player p = e.getPlayer();
        if (realm.isInRealm(p) && !realm.isInternalGameMode(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!realm.isBusy(p) || p.hasPermission("deathdimension.admin")) return;
        String label = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        if (plugin.getConfig().getStringList("realm.allowed-commands").contains(label)) return;
        e.setCancelled(true);
        p.sendMessage(plugin.msg("command-blocked"));
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && realm.isBusy(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (realm.isBusy(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && realm.isBusy(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (realm.isBusy(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> realm.recover(p), 5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        realm.handleQuit(e.getPlayer());
    }
}
