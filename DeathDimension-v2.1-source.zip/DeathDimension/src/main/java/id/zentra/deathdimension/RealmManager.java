package id.zentra.deathdimension;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.data.type.Light;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Inti plugin. Kematian dibatalkan -> animasi tarikan -> pemain dibawa ke realm (void, gelap,
 * kamera sinematik) selama N detik -> dipaksa teleport ke lokasi random aman di overworld.
 * Tidak ada layar respawn, jadi tidak ada spawn acak dari plugin lain.
 */
public final class RealmManager {

    private static final class Realm {
        final long until;
        final long total;
        final BossBar bar;
        final float yaw;
        Cinematic cine;
        int age;
        CompletableFuture<Location> rtp;

        Realm(long until, long total, BossBar bar, float yaw) {
            this.until = until;
            this.total = total;
            this.bar = bar;
            this.yaw = yaw;
        }
    }

    private static final Particle.DustOptions DUST_A = new Particle.DustOptions(Color.fromRGB(255, 45, 45), 1.4f);
    private static final Particle.DustOptions DUST_B = new Particle.DustOptions(Color.fromRGB(130, 0, 210), 1.2f);
    private static final PotionEffectType[] PULL_EFFECTS = {
            PotionEffectType.SLOWNESS, PotionEffectType.NAUSEA, PotionEffectType.LEVITATION
    };

    private final DeathDimension plugin;
    private final RandomTeleporter randomTp;
    private final NamespacedKey keyUntil;
    private final NamespacedKey keyGm;
    private final NamespacedKey keyCine;
    private final Map<UUID, Integer> pulling = new HashMap<>();
    private final Map<UUID, Realm> inRealm = new HashMap<>();
    private final Map<UUID, Float> deathYaw = new HashMap<>();
    private final Map<UUID, Long> protectedUntil = new HashMap<>();
    private final Set<UUID> pendingDeath = new HashSet<>();
    private final Set<UUID> internalTp = new HashSet<>();
    private final Set<UUID> internalGm = new HashSet<>();
    private final BukkitTask task;
    private int counter;

    public RealmManager(DeathDimension plugin) {
        this.plugin = plugin;
        this.randomTp = new RandomTeleporter(plugin);
        this.keyUntil = new NamespacedKey(plugin, "until");
        this.keyGm = new NamespacedKey(plugin, "gm");
        this.keyCine = new NamespacedKey(plugin, "cine");
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    // ------------------------------------------------------------ status

    public boolean isPulling(Player p) { return pulling.containsKey(p.getUniqueId()); }
    public boolean isInRealm(Player p) { return inRealm.containsKey(p.getUniqueId()); }
    public boolean isBusy(Player p) { return isPulling(p) || isInRealm(p); }
    public boolean isInternalTeleport(Player p) { return internalTp.contains(p.getUniqueId()); }
    public boolean isInternalGameMode(Player p) { return internalGm.contains(p.getUniqueId()); }
    public boolean isProtected(Player p) {
        return protectedUntil.getOrDefault(p.getUniqueId(), 0L) > System.currentTimeMillis();
    }

    public void markPending(Player p) { pendingDeath.add(p.getUniqueId()); }
    public boolean consumePending(Player p) { return pendingDeath.remove(p.getUniqueId()); }

    public boolean shouldHandle(Player p) {
        if (p.hasPermission("deathdimension.bypass")) return false;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;
        Location rl = realmLocation();
        if (rl != null && p.getWorld().equals(rl.getWorld())) return false;
        return !cfg().getStringList("disabled-worlds").contains(p.getWorld().getName());
    }

    private FileConfiguration cfg() { return plugin.getConfig(); }

    public long realmMillis() {
        return Math.max(1, cfg().getInt("timing.realm-seconds", 30)) * 1000L;
    }

    private void setGm(Player p, GameMode gm) {
        UUID id = p.getUniqueId();
        internalGm.add(id);
        try {
            p.setGameMode(gm);
        } finally {
            internalGm.remove(id);
        }
    }

    private void heal(Player p) {
        AttributeInstance a = p.getAttribute(Attribute.MAX_HEALTH);
        p.setHealth(a != null ? Math.max(1.0, a.getValue()) : 20.0);
        p.setFoodLevel(20);
        p.setFireTicks(0);
        p.setFallDistance(0f);
    }

    private void runMain(Runnable r) {
        if (Bukkit.isPrimaryThread()) r.run();
        else Bukkit.getScheduler().runTask(plugin, r);
    }

    // ------------------------------------------------------------ world

    public Location realmLocation() {
        String name = cfg().getString("dimension-location.world", "realm_of_the_dead");
        World w = Bukkit.getWorld(name);
        if (w == null) {
            ensureWorld();
            w = Bukkit.getWorld(name);
        }
        if (w == null) return null;
        return new Location(w,
                cfg().getDouble("dimension-location.x", 0.5),
                cfg().getDouble("dimension-location.y", 65.0),
                cfg().getDouble("dimension-location.z", 0.5),
                (float) cfg().getDouble("dimension-location.yaw", 0.0),
                (float) cfg().getDouble("dimension-location.pitch", 0.0));
    }

    public void ensureWorld() {
        String name = cfg().getString("dimension-location.world", "realm_of_the_dead");
        World w = Bukkit.getWorld(name);
        if (w == null && cfg().getBoolean("create-world-if-missing", true)) {
            try {
                WorldCreator wc = new WorldCreator(name);
                wc.environment(World.Environment.NORMAL);
                wc.generator(new VoidGenerator());
                wc.generateStructures(false);
                w = wc.createWorld();
            } catch (Exception ex) {
                plugin.getLogger().warning("Gagal membuat world realm: " + ex.getMessage());
            }
        }
        if (w == null) return;
        // hanya menyentuh world realm, tidak mengubah world lain
        w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        w.setTime(18000L);
        buildPlatform(w);
        w.addPluginChunkTicket(0, 0, plugin);
        // bersihkan sisa kamera/badan kalau server sebelumnya crash
        for (Entity e : w.getEntities())
            if (e.getPersistentDataContainer().has(keyCine, PersistentDataType.BYTE)) e.remove();
    }

    private void buildPlatform(World w) {
        if (!cfg().getBoolean("platform.enabled", true)) return;
        Material m = Material.matchMaterial(cfg().getString("platform.material", "BLACK_CONCRETE"));
        if (m == null || !m.isBlock()) m = Material.BLACK_CONCRETE;
        int r = Math.max(1, cfg().getInt("platform.radius", 4));
        int cx = (int) Math.floor(cfg().getDouble("dimension-location.x", 0.5));
        int cy = (int) Math.floor(cfg().getDouble("dimension-location.y", 65.0)) - 1;
        int cz = (int) Math.floor(cfg().getDouble("dimension-location.z", 0.5));
        for (int x = -r; x <= r; x++)
            for (int z = -r; z <= r; z++)
                if (x * x + z * z <= r * r + 1)
                    w.getBlockAt(cx + x, cy, cz + z).setType(m, false);
        try { // cahaya lembut di atas badan (blok LIGHT tak terlihat)
            Light light = (Light) Material.LIGHT.createBlockData();
            light.setLevel(10);
            w.getBlockAt(cx, cy + 4, cz).setBlockData(light, false);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------ tick loop

    private void tick() {
        counter++;
        pullTick();
        cinematicTick();
        if (counter % 5 == 0) boundaryTick();
        if (counter % 20 == 0) realmTick();
    }

    public void shutdown() {
        task.cancel();
        for (UUID id : new ArrayList<>(pulling.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) clearAnim(p, true);
        }
        for (Map.Entry<UUID, Realm> e : inRealm.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) p.hideBossBar(e.getValue().bar);
            if (e.getValue().cine != null) e.getValue().cine.remove();
        }
        pulling.clear();
        inRealm.clear();
    }

    // ------------------------------------------------------------ pull animation

    public void startPull(Player p) {
        UUID id = p.getUniqueId();
        if (isBusy(p)) return;
        int total = pullTicks();
        pulling.put(id, 0);
        deathYaw.put(id, p.getLocation().getYaw());
        p.setInvulnerable(true);
        int dur = total + 40;
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 4, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, dur + 40, 0, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, dur, 0, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, total, 0, false, false, false));
        p.showTitle(Title.title(plugin.msg("death-title"), plugin.msg("death-subtitle"),
                Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(total * 50L + 400), Duration.ofMillis(300))));
        playSound(p, "sounds.pull-start");
        shockwave(p.getLocation(), p, 0.6);
    }

    /** Jalur cadangan (mati lewat /kill dll): langsung ke realm tanpa animasi di tempat. */
    public void enterNow(Player p) {
        if (isBusy(p)) return;
        deathYaw.put(p.getUniqueId(), p.getLocation().getYaw());
        begin(p, System.currentTimeMillis() + realmMillis(), realmMillis());
    }

    private int pullTicks() { return Math.max(20, cfg().getInt("timing.pull-ticks", 70)); }

    private void pullTick() {
        if (pulling.isEmpty()) return;
        int total = pullTicks();
        List<Player> done = new ArrayList<>();
        Iterator<Map.Entry<UUID, Integer>> it = pulling.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null || !p.isOnline()) {
                it.remove();
                continue;
            }
            int t = en.getValue() + 1;
            en.setValue(t);
            effects(p, t, total);
            if (t >= total) done.add(p);
        }
        for (Player p : done) {
            pulling.remove(p.getUniqueId());
            finishPull(p);
        }
    }

    private void effects(Player p, int t, int total) {
        Location l = p.getLocation();
        World w = l.getWorld();
        double prog = (double) t / total;
        double ang = t * 0.55;
        double r = 2.2 * (1 - prog) + 0.4;
        for (int k = 0; k < 3; k++) {
            double a = ang + k * (Math.PI * 2 / 3);
            Location pl = l.clone().add(Math.cos(a) * r, prog * 2.2 + 0.2, Math.sin(a) * r);
            w.spawnParticle(Particle.SOUL_FIRE_FLAME, pl, 1, 0, 0, 0, 0);
            w.spawnParticle(Particle.DUST, pl, 1, 0, 0, 0, 0, k == 0 ? DUST_A : DUST_B);
        }
        if (t % 2 == 0) {
            double rr = 0.5 + (t % 20) * 0.3;
            for (int i = 0; i < 24; i++) {
                double a = i * (Math.PI * 2 / 24);
                w.spawnParticle(Particle.DUST, l.clone().add(Math.cos(a) * rr, 0.1, Math.sin(a) * rr),
                        1, 0, 0, 0, 0, DUST_A);
            }
        }
        if (t % 10 == 0) {
            w.spawnParticle(Particle.REVERSE_PORTAL, l.clone().add(0, 1, 0), 40, 0.4, 0.8, 0.4, 0.05);
            shockwave(l, p, 0.35);
        }
    }

    private void finishPull(Player p) {
        Location l = p.getLocation();
        World w = l.getWorld();
        w.spawnParticle(Particle.EXPLOSION_EMITTER, l, 1);
        w.spawnParticle(Particle.PORTAL, l.clone().add(0, 1, 0), 200, 0.5, 1, 0.5, 1.2);
        w.spawnParticle(Particle.SONIC_BOOM, l.clone().add(0, 1, 0), 1);
        w.strikeLightningEffect(l);
        shockwave(l, p, 1.0);
        playSound(p, "sounds.pull-end");
        clearAnim(p, false); // DARKNESS dibiarkan supaya tidak ada kilatan terang saat pindah
        begin(p, System.currentTimeMillis() + realmMillis(), realmMillis());
    }

    private void clearAnim(Player p, boolean all) {
        for (PotionEffectType t : PULL_EFFECTS) p.removePotionEffect(t);
        if (all) {
            p.removePotionEffect(PotionEffectType.DARKNESS);
            p.removePotionEffect(PotionEffectType.BLINDNESS);
        }
        p.setInvulnerable(false);
    }

    private void shockwave(Location c, Player self, double scale) {
        if (!cfg().getBoolean("shockwave.enabled", true)) return;
        double radius = cfg().getDouble("shockwave.radius", 8.0);
        double power = cfg().getDouble("shockwave.power", 1.6) * scale;
        for (Entity e : c.getWorld().getNearbyEntities(c, radius, radius, radius)) {
            if (e.equals(self) || !(e instanceof LivingEntity) || e instanceof ArmorStand) continue;
            if (e instanceof Player other && isBusy(other)) continue;
            Vector v = e.getLocation().toVector().subtract(c.toVector());
            v.setY(0);
            if (v.lengthSquared() < 0.0001) v = new Vector(Math.random() - 0.5, 0, Math.random() - 0.5);
            v.normalize().multiply(power).setY(0.45);
            e.setVelocity(v);
        }
    }

    // ------------------------------------------------------------ realm

    private void begin(Player p, long until, long total) {
        UUID id = p.getUniqueId();
        Location dest = realmLocation();
        if (dest == null) {
            p.sendMessage(plugin.msg("admin-no-realm"));
            release(p);
            return;
        }
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        if (!pdc.has(keyGm, PersistentDataType.STRING))
            pdc.set(keyGm, PersistentDataType.STRING, p.getGameMode().name());
        pdc.set(keyUntil, PersistentDataType.LONG, until);

        Realm old = inRealm.remove(id);
        if (old != null) {
            p.hideBossBar(old.bar);
            if (old.cine != null) old.cine.remove();
        }
        BossBar bar = BossBar.bossBar(plugin.msg("realm-bossbar", "time", "" + secondsLeft(until)),
                1f, BossBar.Color.RED, BossBar.Overlay.PROGRESS);
        Realm r = new Realm(until, total, bar, deathYaw.getOrDefault(id, 0f));
        r.age = (int) Math.max(0, (total - (until - System.currentTimeMillis())) / 50);
        inRealm.put(id, r);
        p.showBossBar(bar);

        p.setInvulnerable(true);
        heal(p);
        // cari lokasi random SEKARANG (async) supaya saat waktu habis langsung teleport, tanpa delay
        if (randomTp.enabled()) r.rtp = randomTp.find();
        playSound(p, "sounds.realm-enter");
        forceTo(p, dest, 0, () -> arrive(p, r));
        showRealm(p, r, System.currentTimeMillis());
    }

    /** Teleport ke realm + verifikasi ulang (melawan plugin lain yang menimpa lokasi). */
    private void forceTo(Player p, Location dest, int attempt, Runnable onArrive) {
        UUID id = p.getUniqueId();
        internalTp.add(id);
        p.teleportAsync(dest).whenComplete((ok, ex) -> runMain(() -> {
            internalTp.remove(id);
            if (!p.isOnline() || !inRealm.containsKey(id)) return;
            if (atRealm(p, dest)) {
                if (onArrive != null) onArrive.run();
            } else if (attempt < 6) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (p.isOnline() && inRealm.containsKey(id)) forceTo(p, dest, attempt + 1, onArrive);
                }, 3L);
            } else {
                plugin.getLogger().warning("Tidak bisa memindahkan " + p.getName()
                        + " ke realm (dibatalkan plugin lain?). Pemain dibebaskan.");
                release(p);
            }
        }));
    }

    private boolean atRealm(Player p, Location dest) {
        double lim = cfg().getDouble("realm.max-radius", 40) + 3;
        return p.getWorld().equals(dest.getWorld()) && p.getLocation().distanceSquared(dest) <= lim * lim;
    }

    private void arrive(Player p, Realm r) {
        UUID id = p.getUniqueId();
        if (inRealm.get(id) != r || !p.isOnline()) return;
        Location dest = realmLocation();
        if (dest == null) return;
        int left = secondsLeft(r.until);
        p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, left * 20 + 100, 0, false, false, false));
        boolean ok = false;
        if (cfg().getBoolean("cinematic.enabled", true)) {
            try {
                r.cine = new Cinematic(plugin, p, dest, r.yaw, (float) cfg().getDouble("cinematic.head-scale", 1.0));
                setGm(p, GameMode.SPECTATOR);
                r.cine.tick(p, r.age);
                ok = true;
            } catch (Exception ex) {
                plugin.getLogger().warning("Kamera sinematik gagal, pakai mode biasa: " + ex);
                if (r.cine != null) r.cine.remove();
                r.cine = null;
            }
        }
        if (!ok) setGm(p, GameMode.ADVENTURE);
    }

    private void cinematicTick() {
        if (inRealm.isEmpty()) return;
        for (Map.Entry<UUID, Realm> e : inRealm.entrySet()) {
            Realm r = e.getValue();
            if (r.cine == null) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null) continue;
            r.age++;
            try {
                r.cine.tick(p, r.age);
            } catch (Exception ex) {
                plugin.getLogger().warning("Kamera sinematik error: " + ex);
                r.cine.remove();
                r.cine = null;
                if (p.getGameMode() == GameMode.SPECTATOR) {
                    p.setSpectatorTarget(null);
                    setGm(p, GameMode.ADVENTURE);
                }
            }
        }
    }

    private void boundaryTick() {
        if (inRealm.isEmpty()) return;
        Location dest = realmLocation();
        if (dest == null) return;
        double max = cfg().getDouble("realm.max-radius", 40);
        for (UUID id : new ArrayList<>(inRealm.keySet())) {
            Player p = Bukkit.getPlayer(id);
            Realm r = inRealm.get(id);
            if (p == null || r == null || internalTp.contains(id)) continue;
            if (!p.getWorld().equals(dest.getWorld())) {
                forceTo(p, dest, 0, () -> arrive(p, r));
            } else if (r.cine == null) {
                Location l = p.getLocation();
                double dx = l.getX() - dest.getX(), dz = l.getZ() - dest.getZ();
                if (dx * dx + dz * dz > max * max || l.getY() < dest.getY() - 15) {
                    internalTp.add(id);
                    p.teleport(dest);
                    internalTp.remove(id);
                    p.setFallDistance(0f);
                }
            }
        }
    }

    private int secondsLeft(long until) {
        return (int) Math.max(0, Math.ceil((until - System.currentTimeMillis()) / 1000.0));
    }

    private void realmTick() {
        if (inRealm.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (UUID id : new ArrayList<>(inRealm.keySet())) {
            Player p = Bukkit.getPlayer(id);
            Realm r = inRealm.get(id);
            if (p == null || r == null || !p.isOnline()) continue;
            if (now >= r.until) {
                release(p);
            } else {
                showRealm(p, r, now);
                if (secondsLeft(r.until) == 2)
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 50, 0, false, false, false));
            }
        }
    }

    private void showRealm(Player p, Realm r, long now) {
        int remain = (int) Math.max(0, Math.ceil((r.until - now) / 1000.0));
        String time = String.valueOf(remain);
        String color = remain > 10 ? "<red>" : remain > 5 ? "<yellow>" : "<green>";
        boolean ending = remain <= 3;
        p.showTitle(Title.title(
                plugin.msg(ending ? "realm-ending-title" : "realm-title"),
                plugin.msg(ending ? "realm-ending-subtitle" : "realm-subtitle", "time", time),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1500), Duration.ZERO)));
        p.sendActionBar(plugin.msg("realm-actionbar", "time", time, "color", color));
        r.bar.name(plugin.msg("realm-bossbar", "time", time));
        r.bar.progress((float) Math.max(0.0, Math.min(1.0, (r.until - now) / (double) r.total)));
        if (remain <= 10 && remain > 0) playSound(p, "sounds.realm-tick");
        if (r.cine == null) {
            Location l = p.getLocation().add(0, 1, 0);
            p.getWorld().spawnParticle(Particle.SOUL, l, 6, 1.5, 1.0, 1.5, 0.01);
            p.getWorld().spawnParticle(Particle.SMOKE, l, 10, 2.0, 1.0, 2.0, 0.01);
        }
    }

    // ------------------------------------------------------------ release / recover

    public void release(Player p) {
        UUID id = p.getUniqueId();
        pulling.remove(id);
        Realm r = inRealm.remove(id);
        if (r != null) p.hideBossBar(r.bar);

        PersistentDataContainer pdc = p.getPersistentDataContainer();
        String gmName = pdc.get(keyGm, PersistentDataType.STRING);
        pdc.remove(keyUntil);
        pdc.remove(keyGm);

        if (p.getGameMode() == GameMode.SPECTATOR && p.getSpectatorTarget() != null) p.setSpectatorTarget(null);
        if (r != null && r.cine != null) r.cine.remove();
        clearAnim(p, true);
        if (gmName != null) {
            GameMode gm;
            try {
                gm = GameMode.valueOf(gmName);
            } catch (IllegalArgumentException ex) {
                gm = GameMode.SURVIVAL;
            }
            setGm(p, gm);
        } else if (r != null && p.getGameMode() == GameMode.SPECTATOR) {
            setGm(p, GameMode.SURVIVAL);
        }
        heal(p);

        CompletableFuture<Location> f;
        if (randomTp.enabled()) f = (r != null && r.rtp != null) ? r.rtp : randomTp.find();
        else f = CompletableFuture.completedFuture(legacyDest(p));
        if (f.isDone()) {
            leave(p, f.isCompletedExceptionally() ? null : f.getNow(null));
        } else {
            f.whenComplete((loc, ex) -> runMain(() -> leave(p, ex == null ? loc : null)));
        }
    }

    private Location legacyDest(Player p) {
        Location d = p.getRespawnLocation();
        if (d == null || d.getWorld() == null) d = Bukkit.getWorlds().get(0).getSpawnLocation();
        return d;
    }

    /** Teleport paksa keluar dari realm ke lokasi random yang sudah disiapkan. */
    private void leave(Player p, Location loc) {
        if (!p.isOnline()) {
            randomTp.releaseTicket(loc);
            return;
        }
        UUID id = p.getUniqueId();
        Location d = loc != null ? loc : legacyDest(p);
        int prot = cfg().getInt("post-protection-seconds", 6);
        if (prot > 0) protectedUntil.put(id, System.currentTimeMillis() + prot * 1000L);
        internalTp.add(id);
        p.teleportAsync(d).whenComplete((ok, ex) -> runMain(() -> {
            internalTp.remove(id);
            randomTp.releaseTicket(loc);
            if (!p.isOnline()) return;
            Location l = p.getLocation();
            p.showTitle(Title.title(plugin.msg("released-title"), plugin.msg("released-subtitle"),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(2500), Duration.ofMillis(800))));
            p.sendActionBar(plugin.msg("released-actionbar", "x", "" + l.getBlockX(),
                    "y", "" + l.getBlockY(), "z", "" + l.getBlockZ()));
            playSound(p, "sounds.release");
            Location c = l.clone().add(0, 1, 0);
            l.getWorld().strikeLightningEffect(l);
            l.getWorld().spawnParticle(Particle.END_ROD, c, 80, 0.5, 1.0, 0.5, 0.15);
            l.getWorld().spawnParticle(Particle.REVERSE_PORTAL, c, 100, 0.4, 0.8, 0.4, 0.25);
            l.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, c, 1);
        }));
    }

    /** Dipanggil saat join: lanjutkan hukuman yang tersisa (aman terhadap restart/relog). */
    public void recover(Player p) {
        if (!p.isOnline() || isBusy(p)) return;
        Long until = p.getPersistentDataContainer().get(keyUntil, PersistentDataType.LONG);
        if (until == null) return;
        if (System.currentTimeMillis() >= until) release(p);
        else begin(p, until, realmMillis());
    }

    public void handleQuit(Player p) {
        UUID id = p.getUniqueId();
        pendingDeath.remove(id);
        internalTp.remove(id);
        deathYaw.remove(id);
        protectedUntil.remove(id);
        if (pulling.remove(id) != null) clearAnim(p, true);
        Realm r = inRealm.remove(id);
        if (r != null) {
            p.hideBossBar(r.bar); // PDC tetap menyimpan sisa waktu
            if (r.cine != null) r.cine.remove();
        }
    }

    // ------------------------------------------------------------ util

    private void playSound(Player p, String path) {
        String s = cfg().getString(path, "");
        if (s == null || s.isBlank()) return;
        String[] a = s.split(",");
        float vol = 1f, pitch = 1f;
        try {
            if (a.length > 1) vol = Float.parseFloat(a[1].trim());
            if (a.length > 2) pitch = Float.parseFloat(a[2].trim());
        } catch (NumberFormatException ignored) {
        }
        p.playSound(p.getLocation(), a[0].trim(), vol, pitch);
    }
}
